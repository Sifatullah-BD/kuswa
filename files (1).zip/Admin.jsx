import React, { useEffect, useState, useRef } from "react";
import { Navigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useLang } from "../context/LanguageContext";
import { api, formatApiError } from "../lib/api";
import { toast } from "sonner";
import {
  LogOut, Home, Newspaper, Calendar, Users as UsersIcon,
  Image as ImageIcon, MessageSquare, Settings, Trash2,
  Check, X, Plus, Send, Upload, Star,
} from "lucide-react";

const TABS = [
  { key: "hero",      label: "Hero Slides",  Icon: Star },
  { key: "news",      label: "News",         Icon: Newspaper },
  { key: "events",    label: "Events",       Icon: Calendar },
  { key: "members",   label: "Members",      Icon: UsersIcon },
  { key: "committee", label: "Committee",    Icon: UsersIcon },
  { key: "gallery",   label: "Gallery",      Icon: ImageIcon },
  { key: "messages",  label: "Messages",     Icon: MessageSquare },
  { key: "settings",  label: "Settings",     Icon: Settings },
];

// ---------- Reusable field components ----------
function Field({ label, ...props }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="text-kuswa-muted font-medium">{label}</span>
      <input {...props} className="px-3 py-2 rounded-lg border border-kuswa-bg focus:border-kuswa-dark-blue outline-none" />
    </label>
  );
}
function TextArea({ label, ...props }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="text-kuswa-muted font-medium">{label}</span>
      <textarea rows={3} {...props} className="px-3 py-2 rounded-lg border border-kuswa-bg focus:border-kuswa-dark-blue outline-none" />
    </label>
  );
}

// ---------- Image Upload Button ----------
// Converts selected file to base64, POSTs to /api/upload/image, returns URL
function ImageUploadBtn({ onUploaded, label = "ছবি আপলোড করুন" }) {
  const inputRef = useRef();
  const [uploading, setUploading] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        try {
          const base64data = ev.target.result; // includes data:image/...;base64, prefix
          const res = await api.post("/upload/image", {
            filename: file.name,
            data: base64data,
          });
          onUploaded(res.data.url);
          toast.success("ছবি আপলোড সফল হয়েছে ✅");
        } catch (err) {
          toast.error("আপলোড ব্যর্থ: " + (err.response?.data?.detail || err.message));
        } finally {
          setUploading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch {
      setUploading(false);
    }
    // reset so same file can be re-selected
    e.target.value = "";
  };

  return (
    <div className="flex items-center gap-2">
      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
      <button
        type="button"
        disabled={uploading}
        onClick={() => inputRef.current.click()}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-kuswa-light-blue/20 text-kuswa-dark-blue hover:bg-kuswa-dark-blue hover:text-white transition disabled:opacity-50"
      >
        <Upload size={13} /> {uploading ? "আপলোড হচ্ছে..." : label}
      </button>
    </div>
  );
}

// ---------- Image field row (URL input + upload button + preview) ----------
function ImageField({ label, urlKey, form, setForm }) {
  return (
    <div className="flex flex-col gap-1.5 text-sm sm:col-span-2">
      <span className="text-kuswa-muted font-medium">{label}</span>
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <input
            type="url"
            value={form[urlKey] ?? ""}
            onChange={(e) => setForm({ ...form, [urlKey]: e.target.value })}
            placeholder="https://... বা নিচে থেকে আপলোড করুন"
            className="flex-1 px-3 py-2 rounded-lg border border-kuswa-bg focus:border-kuswa-dark-blue outline-none text-sm"
          />
          <ImageUploadBtn onUploaded={(url) => setForm({ ...form, [urlKey]: url })} />
        </div>
        {form[urlKey] && (
          <img
            src={form[urlKey]}
            alt="preview"
            className="h-24 w-auto rounded-lg object-cover border border-kuswa-bg"
          />
        )}
      </div>
    </div>
  );
}

// ---------- Defaults ----------
const emptyNews      = { title_en: "", title_bn: "", content_en: "", content_bn: "", image_url: "", category: "news", is_published: true };
const emptyEvent     = { title_en: "", title_bn: "", description_en: "", description_bn: "", event_date: "", location_en: "", location_bn: "", image_url: "", is_upcoming: true };
const emptyCommittee = { name_en: "", name_bn: "", position_en: "", position_bn: "", category: "executive", photo_url: "", bio_en: "", bio_bn: "", order: 0 };
const emptyGallery   = { title_en: "", title_bn: "", media_type: "photo", media_url: "", album: "general", description_en: "", description_bn: "" };
const emptyHero      = { image_url: "", caption_en: "", caption_bn: "", order: 0 };

// ==================== Main Admin Component ====================
export default function Admin() {
  const { user, checking, logout } = useAuth();
  const [tab, setTab] = useState("hero");

  if (checking) return <div className="min-h-screen grid place-items-center">Loading...</div>;
  if (!user || user.role !== "admin") return <Navigate to="/login" replace />;

  return (
    <div className="min-h-screen bg-kuswa-bg" data-testid="admin-dashboard">
      {/* Top nav */}
      <div className="bg-white border-b border-kuswa-bg sticky top-0 z-40">
        <div className="container-x flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2 text-kuswa-dark-blue font-bold">
              <Home size={18} /> KUSWA
            </Link>
            <span className="text-sm text-kuswa-muted hidden sm:inline">Admin Dashboard</span>
          </div>
          <button onClick={logout} className="inline-flex items-center gap-2 px-3 py-2 rounded-full text-sm font-semibold hover:bg-kuswa-bg" data-testid="admin-logout">
            <LogOut size={16} /> Logout
          </button>
        </div>
        <div className="container-x flex gap-1 overflow-x-auto py-2">
          {TABS.map(({ key, label, Icon }) => (
            <button key={key} onClick={() => setTab(key)} data-testid={`admin-tab-${key}`}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition ${
                tab === key ? "bg-kuswa-dark-blue text-white" : "text-kuswa-ink hover:bg-kuswa-bg"
              }`}>
              <Icon size={14} /> {label}
            </button>
          ))}
        </div>
      </div>

      <div className="container-x py-8">
        {tab === "hero"      && <HeroTab />}
        {tab === "news"      && <CrudList endpoint="/news"      empty={emptyNews}      title="News & Notices"      imageUrlKey="image_url"
          fields={[
            ["title_en",  "Title (EN)"], ["title_bn",  "Title (BN)"],
            ["content_en","Content (EN)","textarea"], ["content_bn","Content (BN)","textarea"],
            ["category",  "Category (news|notice)"],
          ]}
          renderItem={(n) => <><b>{n.title_en}</b><div className="text-xs text-kuswa-muted">{n.title_bn}</div></>}
        />}
        {tab === "events"    && <CrudList endpoint="/events"    empty={emptyEvent}     title="Events"             imageUrlKey="image_url"
          fields={[
            ["title_en",      "Title (EN)"], ["title_bn",      "Title (BN)"],
            ["event_date",    "Event Date"], ["location_en",   "Location (EN)"],
            ["location_bn",   "Location (BN)"],
            ["description_en","Description (EN)","textarea"], ["description_bn","Description (BN)","textarea"],
          ]}
          renderItem={(e) => <><b>{e.title_en}</b><div className="text-xs text-kuswa-muted">{e.event_date} · {e.location_en}</div></>}
        />}
        {tab === "committee" && <CrudList endpoint="/committee" empty={emptyCommittee} title="Executive Committee" imageUrlKey="photo_url"
          fields={[
            ["name_en",    "Name (EN)"],    ["name_bn",    "Name (BN)"],
            ["position_en","Position (EN)"],["position_bn","Position (BN)"],
            ["category",   "Category (executive|advisor|ulama|office|student|expat|business|youth|sports|culture|agriculture)"],
            ["order",      "Order","number"],
            ["bio_en",     "Bio (EN)","textarea"], ["bio_bn","Bio (BN)","textarea"],
          ]}
          renderItem={(m) => <><b>{m.name_en}</b><div className="text-xs text-kuswa-muted">{m.position_en} · <span className="text-kuswa-orange">{m.category || "executive"}</span></div></>}
        />}
        {tab === "gallery"   && <CrudList endpoint="/gallery"   empty={emptyGallery}   title="Gallery"            imageUrlKey="media_url"
          fields={[
            ["title_en",      "Title (EN)"], ["title_bn",       "Title (BN)"],
            ["media_type",    "Media Type (photo|video)"], ["album","Album"],
            ["description_en","Description (EN)","textarea"], ["description_bn","Description (BN)","textarea"],
          ]}
          renderItem={(g) => <><b>{g.title_en}</b><div className="text-xs text-kuswa-muted">{g.media_type} · {g.album}</div></>}
        />}
        {tab === "members"   && <MembersTab />}
        {tab === "messages"  && <MessagesTab />}
        {tab === "settings"  && <SettingsTab />}
      </div>
    </div>
  );
}

// ==================== Hero Slides Tab ====================
function HeroTab() {
  const [items, setItems]     = useState([]);
  const [form, setForm]       = useState(emptyHero);
  const [open, setOpen]       = useState(false);
  const [uploading, setUp]    = useState(false);
  const inputRef              = useRef();

  const load = () => api.get("/hero-images").then((r) => setItems(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUp(true);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const res = await api.post("/upload/image", { filename: file.name, data: ev.target.result });
        setForm((f) => ({ ...f, image_url: res.data.url }));
        toast.success("ছবি আপলোড সফল ✅");
      } catch (err) {
        toast.error("আপলোড ব্যর্থ: " + (err.response?.data?.detail || err.message));
      } finally {
        setUp(false);
      }
      e.target.value = "";
    };
    reader.readAsDataURL(file);
  };

  const save = async (e) => {
    e.preventDefault();
    if (!form.image_url) { toast.error("ছবি আপলোড বা URL দিন"); return; }
    try {
      await api.post("/hero-images", { ...form, order: Number(form.order || 0) });
      toast.success("Hero slide যোগ হয়েছে ✅");
      setForm(emptyHero); setOpen(false); load();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail) || err.message); }
  };

  const del = async (id) => {
    if (!window.confirm("এই slide মুছে ফেলবেন?")) return;
    try { await api.delete(`/hero-images/${id}`); toast.success("মুছে ফেলা হয়েছে"); load(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail) || err.message); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-kuswa-dark-blue">Hero Slideshow</h2>
          <p className="text-xs text-kuswa-muted mt-1">এখানে আপলোড করা ছবিগুলো পাবলিক হোম পেজে প্রতি ৪ সেকেন্ডে স্বয়ংক্রিয়ভাবে পরিবর্তিত হবে।</p>
        </div>
        <button onClick={() => setOpen((v) => !v)} className="btn-primary !py-2 !px-4 text-sm">
          <Plus size={16} /> {open ? "বন্ধ করুন" : "নতুন Slide যোগ করুন"}
        </button>
      </div>

      {open && (
        <form onSubmit={save} className="card-soft space-y-4">
          <h3 className="font-semibold text-kuswa-dark-blue">নতুন Hero ছবি</h3>

          {/* Upload area */}
          <div className="flex flex-col gap-2">
            <span className="text-sm text-kuswa-muted font-medium">ছবি আপলোড করুন *</span>
            <div
              className="border-2 border-dashed border-kuswa-light-blue rounded-xl p-6 text-center cursor-pointer hover:bg-kuswa-light-blue/5 transition"
              onClick={() => inputRef.current.click()}
            >
              {form.image_url ? (
                <img src={form.image_url} alt="preview" className="mx-auto max-h-48 rounded-lg object-cover" />
              ) : (
                <div className="space-y-2">
                  <Upload size={32} className="mx-auto text-kuswa-light-blue" />
                  <p className="text-sm text-kuswa-muted">ক্লিক করে ছবি বেছে নিন</p>
                  <p className="text-xs text-kuswa-muted">JPG, PNG, WebP — সর্বোচ্চ 10MB</p>
                </div>
              )}
            </div>
            <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
            {uploading && <p className="text-xs text-kuswa-muted animate-pulse">আপলোড হচ্ছে...</p>}

            {/* OR manual URL */}
            <div className="flex items-center gap-2">
              <div className="flex-1 h-px bg-kuswa-bg" />
              <span className="text-xs text-kuswa-muted">অথবা URL দিন</span>
              <div className="flex-1 h-px bg-kuswa-bg" />
            </div>
            <input
              type="url"
              value={form.image_url}
              onChange={(e) => setForm({ ...form, image_url: e.target.value })}
              placeholder="https://example.com/image.jpg"
              className="px-3 py-2 rounded-lg border border-kuswa-bg focus:border-kuswa-dark-blue outline-none text-sm"
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Caption (EN)" value={form.caption_en} onChange={(e) => setForm({ ...form, caption_en: e.target.value })} />
            <Field label="Caption (BN)" value={form.caption_bn} onChange={(e) => setForm({ ...form, caption_bn: e.target.value })} />
            <Field label="Order (সিরিয়াল)" type="number" value={form.order} onChange={(e) => setForm({ ...form, order: e.target.value })} />
          </div>
          <button type="submit" className="btn-primary w-full">Hero Slide সংরক্ষণ করুন</button>
        </form>
      )}

      {/* Current slides */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.length === 0 && (
          <div className="card-soft text-kuswa-muted col-span-full text-center py-12">
            <Star size={32} className="mx-auto mb-2 opacity-30" />
            <p>কোনো Hero ছবি নেই। উপরে "নতুন Slide যোগ করুন" ক্লিক করুন।</p>
          </div>
        )}
        {items.map((img, idx) => (
          <div key={img.id} className="card-soft !p-0 overflow-hidden group relative">
            <img
              src={img.image_url}
              alt={img.caption_en || `Slide ${idx + 1}`}
              className="w-full h-44 object-cover"
            />
            <div className="p-3">
              <p className="text-sm font-semibold text-kuswa-dark-blue truncate">{img.caption_bn || img.caption_en || `Slide ${idx + 1}`}</p>
              <p className="text-xs text-kuswa-muted">Order: {img.order}</p>
            </div>
            <button
              onClick={() => del(img.id)}
              className="absolute top-2 right-2 p-1.5 rounded-full bg-red-500 text-white opacity-0 group-hover:opacity-100 transition"
            >
              <Trash2 size={13} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== Generic CRUD List (with image upload) ====================
function CrudList({ endpoint, empty, title, fields, renderItem, imageUrlKey }) {
  const [items,   setItems]   = useState([]);
  const [form,    setForm]    = useState(empty);
  const [editing, setEditing] = useState(null);
  const [open,    setOpen]    = useState(false);
  const [waNotif, setWaNotif] = useState(null);

  const load = () => api.get(endpoint).then((r) => setItems(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    try {
      const payload = { ...form };
      if (payload.order !== undefined) payload.order = Number(payload.order || 0);
      let res;
      if (editing) {
        await api.put(`${endpoint}/${editing}`, payload);
      } else {
        res = await api.post(endpoint, payload);
        if (res?.data?._wa_text) {
          setWaNotif({ text: res.data._wa_text, group: res.data._wa_group_link, admin: res.data._wa_admin_link });
        }
      }
      toast.success("সংরক্ষণ হয়েছে ✅");
      setForm(empty); setEditing(null); setOpen(false); load();
    } catch (err) { toast.error(formatApiError(err.response?.data?.detail) || err.message); }
  };

  const del = async (id) => {
    if (!window.confirm("মুছে ফেলবেন?")) return;
    try { await api.delete(`${endpoint}/${id}`); toast.success("মুছে ফেলা হয়েছে"); load(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail) || err.message); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-kuswa-dark-blue">{title}</h2>
        <button onClick={() => { setForm(empty); setEditing(null); setOpen(!open); }} className="btn-primary !py-2 !px-4 text-sm">
          <Plus size={16} /> {open ? "বন্ধ করুন" : "নতুন যোগ করুন"}
        </button>
      </div>

      {open && (
        <form onSubmit={save} className="card-soft grid sm:grid-cols-2 gap-4" data-testid="admin-form">
          {fields.map(([k, label, type]) =>
            type === "textarea"
              ? <div key={k} className="sm:col-span-2"><TextArea label={label} value={form[k] ?? ""} onChange={(e) => setForm({ ...form, [k]: e.target.value })} /></div>
              : <Field key={k} label={label} type={type || "text"} value={form[k] ?? ""} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
          )}

          {/* Image upload row */}
          {imageUrlKey && (
            <ImageField
              label={imageUrlKey === "media_url" ? "Media URL / ছবি আপলোড করুন" : "Image URL / ছবি আপলোড করুন"}
              urlKey={imageUrlKey}
              form={form}
              setForm={setForm}
            />
          )}

          <button type="submit" className="btn-primary sm:col-span-2 mt-2">{editing ? "আপডেট করুন" : "তৈরি করুন"}</button>
        </form>
      )}

      {/* WhatsApp notification panel */}
      {waNotif && (
        <div className="rounded-2xl p-5 bg-green-50 border border-green-200 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-green-800 flex items-center gap-2"><Send size={16}/> WhatsApp নোটিশ পাঠান</h3>
            <button onClick={() => setWaNotif(null)} className="text-green-600 hover:text-green-800 text-xs">✕ বন্ধ করুন</button>
          </div>
          <pre className="bg-white rounded-xl p-3 text-xs text-gray-700 whitespace-pre-wrap border border-green-100 font-sans">{waNotif.text}</pre>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => { navigator.clipboard.writeText(waNotif.text); toast.success("কপি হয়েছে!"); }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold bg-white border border-green-300 hover:bg-green-600 hover:text-white transition">
              📋 টেক্সট কপি করুন
            </button>
            {waNotif.group && (
              <a href={waNotif.group} target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold bg-green-600 text-white hover:bg-green-700 transition">
                👥 গ্রুপে শেয়ার করুন
              </a>
            )}
            {waNotif.admin && (
              <a href={waNotif.admin} target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold bg-white border border-green-300 hover:bg-green-600 hover:text-white transition">
                📱 WhatsApp খুলুন
              </a>
            )}
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {items.length === 0 && <div className="card-soft text-kuswa-muted">কোনো আইটেম নেই</div>}
        {items.map((it) => (
          <div key={it.id} className="card-soft flex items-start gap-4">
            {/* Thumbnail */}
            {(it.image_url || it.photo_url || it.media_url) && (
              <img
                src={it.image_url || it.photo_url || it.media_url}
                alt=""
                className="w-16 h-16 rounded-lg object-cover shrink-0 border border-kuswa-bg"
              />
            )}
            <div className="flex-1">{renderItem(it)}</div>
            <div className="flex gap-2 shrink-0 flex-col sm:flex-row">
              <button onClick={() => { setForm(it); setEditing(it.id); setOpen(true); window.scrollTo(0,0); }}
                className="px-3 py-1.5 rounded-full text-xs bg-kuswa-bg hover:bg-kuswa-dark-blue hover:text-white">Edit</button>
              {(endpoint === "/news" || endpoint === "/events") && (
                <button
                  title="WhatsApp-এ শেয়ার করুন"
                  onClick={async () => {
                    try {
                      const { data } = await api.post("/notifications/whatsapp", { type: endpoint === "/news" ? "news" : "event", id: it.id });
                      setWaNotif({ text: data.text, group: data.whatsapp_group_link, admin: data.admin_link });
                      window.scrollTo(0, 0);
                    } catch { toast.error("WhatsApp লিংক তৈরিতে সমস্যা"); }
                  }}
                  className="px-3 py-1.5 rounded-full text-xs bg-green-50 text-green-700 hover:bg-green-600 hover:text-white"
                >
                  <Send size={14} />
                </button>
              )}
              <button onClick={() => del(it.id)} className="px-3 py-1.5 rounded-full text-xs bg-red-50 text-red-600 hover:bg-red-600 hover:text-white"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== Members Tab ====================
function MembersTab() {
  const [items,  setItems]  = useState([]);
  const [filter, setFilter] = useState("");
  const load = () => api.get(`/members/admin${filter ? `?status_filter=${filter}` : ""}`).then((r) => setItems(r.data)).catch(() => {});
  useEffect(() => { load(); }, [filter]);

  const setStatus = async (id, status) => {
    try { await api.put(`/members/${id}/status`, { status }); toast.success("আপডেট হয়েছে"); load(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail) || err.message); }
  };
  const del = async (id) => {
    if (!window.confirm("মুছে ফেলবেন?")) return;
    try { await api.delete(`/members/${id}`); load(); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail)); }
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <h2 className="text-2xl font-bold text-kuswa-dark-blue">সদস্য আবেদন</h2>
        <div className="flex gap-2 flex-wrap">
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="px-3 py-2 rounded-lg border border-kuswa-bg" data-testid="member-filter">
            <option value="">সব</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
          <button
            onClick={async () => {
              const msg = window.prompt("সব অনুমোদিত সদস্যদের পাঠানোর জন্য বার্তা লিখুন:");
              if (!msg) return;
              const { data } = await api.get("/notifications/members/whatsapp");
              if (!data.length) { alert("কোনো অনুমোদিত সদস্য নেই"); return; }
              const text = encodeURIComponent(msg);
              const links = data.map(m => `https://wa.me/${m.wa_link.split("wa.me/")[1].split("?")[0]}?text=${text}`);
              navigator.clipboard.writeText(links.join(" | "));
              window.open(links[0], "_blank");
              alert(`${data.length} জন সদস্যের WhatsApp লিংক কপি হয়েছে।`);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs bg-green-600 text-white hover:bg-green-700 font-semibold"
          >
            <Send size={14} /> সবাইকে WhatsApp বার্তা
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {items.length === 0 && <div className="card-soft text-kuswa-muted">কোনো আবেদন নেই</div>}
        {items.map((m) => (
          <div key={m.id} className="card-soft flex flex-wrap items-start justify-between gap-4" data-testid={`admin-member-${m.id}`}>
            <div className="flex items-start gap-3 flex-1 min-w-[200px]">
              {/* Member photo */}
              {m.photo_url ? (
                <img src={m.photo_url} alt={m.name} className="w-14 h-14 rounded-full object-cover border-2 border-kuswa-light-blue/30 shrink-0" />
              ) : (
                <div className="w-14 h-14 rounded-full bg-gradient-section grid place-items-center text-white font-bold text-lg shrink-0">
                  {m.name?.[0]?.toUpperCase() || "?"}
                </div>
              )}
              <div>
                <div className="font-bold text-kuswa-dark-blue">{m.name}</div>
                <div className="text-xs text-kuswa-muted mt-0.5">{m.email} · {m.mobile}</div>
                <div className="text-xs text-kuswa-muted">{m.address}</div>
                {m.nid_or_birth_reg && <div className="text-xs text-kuswa-muted">NID: {m.nid_or_birth_reg}</div>}
                <span className={`inline-block mt-1.5 px-2 py-0.5 rounded-full text-xs font-semibold ${
                  m.status === "approved" ? "bg-green-100 text-green-700" :
                  m.status === "rejected" ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"
                }`}>{m.status}</span>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => setStatus(m.id, "approved")} className="px-3 py-1.5 rounded-full text-xs bg-green-50 text-green-700 hover:bg-green-600 hover:text-white" data-testid={`approve-${m.id}`}><Check size={14} /></button>
              <button onClick={() => setStatus(m.id, "rejected")}  className="px-3 py-1.5 rounded-full text-xs bg-red-50 text-red-700 hover:bg-red-600 hover:text-white"><X size={14} /></button>
              {(m.whatsapp || m.mobile) && (
                <a href={`https://wa.me/${(m.whatsapp || m.mobile).replace(/[^0-9]/g,"").replace(/^0/,"880")}`}
                   target="_blank" rel="noreferrer"
                   className="px-3 py-1.5 rounded-full text-xs bg-green-50 text-green-700 hover:bg-green-600 hover:text-white"
                   title="WhatsApp">
                  <Send size={14} />
                </a>
              )}
              <button onClick={() => del(m.id)} className="px-3 py-1.5 rounded-full text-xs bg-kuswa-bg hover:bg-kuswa-dark-blue hover:text-white"><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== Messages Tab ====================
function MessagesTab() {
  const [items, setItems] = useState([]);
  const load = () => api.get("/contact").then((r) => setItems(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const del = async (id) => { if (!window.confirm("মুছে ফেলবেন?")) return; await api.delete(`/contact/${id}`); load(); };
  return (
    <div>
      <h2 className="text-2xl font-bold text-kuswa-dark-blue mb-4">Contact Messages</h2>
      <div className="space-y-3">
        {items.length === 0 && <div className="card-soft text-kuswa-muted">কোনো বার্তা নেই</div>}
        {items.map((m) => (
          <div key={m.id} className="card-soft">
            <div className="flex justify-between items-start gap-4">
              <div>
                <div className="font-bold text-kuswa-dark-blue">{m.name} <span className="text-xs text-kuswa-muted">· {m.email}</span></div>
                <div className="text-xs text-kuswa-muted">{m.subject}</div>
              </div>
              <button onClick={() => del(m.id)} className="px-3 py-1.5 rounded-full text-xs bg-red-50 text-red-600"><Trash2 size={14} /></button>
            </div>
            <p className="mt-3 text-sm text-kuswa-ink">{m.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== Settings Tab ====================
function SettingsTab() {
  const [s, setS] = useState({});
  useEffect(() => { api.get("/settings").then((r) => setS(r.data)).catch(() => {}); }, []);
  const save = async (e) => {
    e.preventDefault();
    try { await api.put("/settings", s); toast.success("সেটিংস সংরক্ষণ হয়েছে ✅"); }
    catch (err) { toast.error(formatApiError(err.response?.data?.detail) || err.message); }
  };
  const f = (k, l) => <Field label={l} value={s[k] ?? ""} onChange={(e) => setS({ ...s, [k]: e.target.value })} />;
  return (
    <div>
      <h2 className="text-2xl font-bold text-kuswa-dark-blue mb-4">Site Settings</h2>
      <form onSubmit={save} className="card-soft grid sm:grid-cols-2 gap-4" data-testid="admin-settings-form">
        <div className="sm:col-span-2 text-xs font-semibold text-kuswa-muted uppercase tracking-wide pt-2">💳 Payment Info</div>
        {f("bank_name","Bank Name")} {f("bank_account_holder","Account Holder Name")}
        {f("bank_account","Bank Account")} {f("bank_branch","Bank Branch")}
        {f("bkash_number","bKash Number")} {f("nagad_number","Nagad Number")}
        {f("rocket_number","Rocket Number")}
        <div className="sm:col-span-2 text-xs font-semibold text-kuswa-muted uppercase tracking-wide pt-2">📞 Contact Info</div>
        {f("contact_phone","Phone")} {f("contact_email","Email")}
        {f("contact_address_en","Address (EN)")} {f("contact_address_bn","Address (BN)")}
        <div className="sm:col-span-2 text-xs font-semibold text-kuswa-muted uppercase tracking-wide pt-2">🟢 WhatsApp সেটিংস</div>
        {f("whatsapp_admin_number","Admin WhatsApp Number (01XXXXXXXXX)")}
        <label className="flex flex-col gap-1 text-sm sm:col-span-2">
          <span className="text-kuswa-muted font-medium">WhatsApp Group Link (Invite Link)</span>
          <input value={s["whatsapp_group_link"] ?? ""} onChange={(e) => setS({ ...s, whatsapp_group_link: e.target.value })}
            placeholder="https://chat.whatsapp.com/xxxxxx"
            className="px-3 py-2 rounded-lg border border-kuswa-bg focus:border-kuswa-dark-blue outline-none" />
        </label>
        <div className="sm:col-span-2 text-xs font-semibold text-kuswa-muted uppercase tracking-wide pt-2">🌐 Social & Map</div>
        {f("facebook_url","Facebook URL")} {f("youtube_url","YouTube URL")}
        <div className="sm:col-span-2">{f("map_embed_url","Map Embed URL")}</div>
        <button type="submit" className="btn-primary sm:col-span-2 mt-2">সেটিংস সংরক্ষণ করুন</button>
      </form>
    </div>
  );
}

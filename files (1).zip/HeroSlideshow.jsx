/**
 * HeroSlideshow.jsx
 *
 * Fetches hero images from /api/hero-images and displays them
 * as a full-width slideshow changing every 4 seconds.
 *
 * Usage in Home.jsx:
 *   import HeroSlideshow from "./HeroSlideshow";
 *   <HeroSlideshow />
 *
 * If no images are uploaded yet, falls back to the original static hero.
 */
import React, { useEffect, useState, useCallback } from "react";
import { api } from "../lib/api";
import { useLang } from "../context/LanguageContext";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function HeroSlideshow({ fallbackContent }) {
  const { lang } = useLang();
  const [slides,   setSlides]   = useState([]);
  const [current,  setCurrent]  = useState(0);
  const [loaded,   setLoaded]   = useState(false);
  const [paused,   setPaused]   = useState(false);

  // Fetch hero images on mount
  useEffect(() => {
    api.get("/hero-images")
      .then((r) => {
        setSlides(r.data || []);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, []);

  // Auto-advance every 4 seconds
  useEffect(() => {
    if (slides.length < 2 || paused) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [slides.length, paused]);

  const prev = useCallback(() => setCurrent((p) => (p - 1 + slides.length) % slides.length), [slides.length]);
  const next = useCallback(() => setCurrent((p) => (p + 1) % slides.length), [slides.length]);

  // No slides yet → render fallback (original hero)
  if (!loaded) return null; // brief load
  if (slides.length === 0) return fallbackContent || null;

  const slide = slides[current];

  return (
    <section
      className="relative w-full overflow-hidden bg-kuswa-dark-blue"
      style={{ minHeight: "480px", maxHeight: "680px" }}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Slides */}
      {slides.map((s, idx) => (
        <div
          key={s.id}
          aria-hidden={idx !== current}
          className="absolute inset-0 transition-opacity duration-700"
          style={{ opacity: idx === current ? 1 : 0, pointerEvents: idx === current ? "auto" : "none" }}
        >
          <img
            src={s.image_url}
            alt={s.caption_en || `Slide ${idx + 1}`}
            className="w-full h-full object-cover"
            loading={idx === 0 ? "eager" : "lazy"}
          />
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        </div>
      ))}

      {/* Caption */}
      {(slide.caption_bn || slide.caption_en) && (
        <div className="absolute bottom-16 left-0 right-0 text-center px-6 pointer-events-none">
          <p className="text-white text-xl sm:text-2xl font-bold drop-shadow-lg">
            {lang === "bn" ? (slide.caption_bn || slide.caption_en) : (slide.caption_en || slide.caption_bn)}
          </p>
        </div>
      )}

      {/* Navigation arrows */}
      {slides.length > 1 && (
        <>
          <button
            onClick={prev}
            aria-label="Previous slide"
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 backdrop-blur-sm flex items-center justify-center text-white transition"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            aria-label="Next slide"
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 backdrop-blur-sm flex items-center justify-center text-white transition"
          >
            <ChevronRight size={20} />
          </button>
        </>
      )}

      {/* Dot indicators */}
      {slides.length > 1 && (
        <div className="absolute bottom-5 left-0 right-0 flex justify-center gap-2">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrent(idx)}
              aria-label={`Slide ${idx + 1}`}
              className={`rounded-full transition-all ${
                idx === current
                  ? "w-6 h-2.5 bg-white"
                  : "w-2.5 h-2.5 bg-white/50 hover:bg-white/70"
              }`}
            />
          ))}
        </div>
      )}
    </section>
  );
}

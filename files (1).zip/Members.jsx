import React, { useEffect, useState } from "react";
import { useLang } from "../context/LanguageContext";
import { api, formatApiError } from "../lib/api";
import { toast } from "sonner";
import { UserPlus, MessageCircle } from "lucide-react";

const initialForm = {
  name: "", father_name: "", dob: "", address: "", profession: "",
  institution: "", education: "", email: "", mobile: "", whatsapp: "",
  blood_group: "", nid_or_birth_reg: "", photo_url: "",
};

export default function Members() {
  const { t, lang } = useLang();
  const [members, setMembers] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.get("/members/public").then((r) => setMembers(r.data)).catch(() => {});
  }, []);

  const onChange = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      // whatsapp defaults to mobile if empty
      const payload = { ...form, whatsapp: form.whatsapp || form.mobile };
      await api.post("/members", payload);
      toast.success(t.member_form.success);
      setForm(initialForm);
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const f = t.member_form;

  const fields = [
    [{ key: "name", label: f.name, type: "text", req: true }],
    [{ key: "father_name", label: f.father_name, type: "text", req: true }],
    [{ key: "dob", label: f.dob, type: "date", req: false }],
    [{ key: "address", label: f.address, type: "text", req: true }],
    [{ key: "profession", label: f.profession, type: "text", req: false }],
    [{ key: "institution", label: f.institution, type: "text", req: false }],
    [{ key: "education", label: f.education, type: "text", req: false }],
    [{ key: "email", label: f.email, type: "email", req: true }],
    [{ key: "mobile", label: f.mobile, type: "tel", req: true }],
    [{ key: "whatsapp", label: lang === "bn" ? "হোয়াটসঅ্যাপ নম্বর" : "WhatsApp Number", type: "tel", req: false, hint: lang === "bn" ? "ফাঁকা রাখলে মোবাইল নম্বর ব্যবহার হবে" : "Leave blank to use mobile number", icon: "wa" }],
    [{ key: "blood_group", label: f.blood_group, type: "text", req: false }],
    [{ key: "nid_or_birth_reg", label: f.nid, type: "text", req: false }],
    [{ key: "photo_url", label: f.photo_url, type: "url", req: false }],
  ];

  return (
    <div data-testid="members-page">
      <section className="bg-gradient-soft py-20">
        <div className="container-x">
          <h1 className={`text-4xl sm:text-5xl font-bold ${lang === "bn" ? "font-bn" : "font-display"} text-kuswa-dark-blue`}>
            {t.sections.members_title}
          </h1>
          <p className="mt-3 text-kuswa-muted">{t.sections.members_sub}</p>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-x grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <div className="card-soft" data-testid="member-form-card">
              <h2 className={`text-2xl font-bold flex items-center gap-2 ${lang === "bn" ? "font-bn" : "font-display"}`}>
                <UserPlus className="text-kuswa-orange" /> {f.title}
              </h2>

              {/* WhatsApp notice */}
              <div className="mt-4 flex items-start gap-3 p-3 rounded-xl bg-green-50 border border-green-200">
                <MessageCircle size={18} className="text-green-600 mt-0.5 shrink-0" />
                <p className="text-xs text-green-700">
                  {lang === "bn"
                    ? "সদস্য অনুমোদনের পর কুশার সকল নোটিশ ও ইভেন্ট আপনার হোয়াটসঅ্যাপে পৌঁছে যাবে।"
                    : "After approval, all KUSWA notices and events will be sent to your WhatsApp."}
                </p>
              </div>

              <form onSubmit={submit} className="mt-6 grid sm:grid-cols-2 gap-4" data-testid="member-form">
                {fields.map(([field]) => (
                  <label key={field.key} className="flex flex-col gap-1.5 text-sm">
                    <span className="text-kuswa-muted font-medium flex items-center gap-1.5">
                      {field.icon === "wa" && <MessageCircle size={13} className="text-green-600" />}
                      {field.label} {field.req && <span className="text-kuswa-orange">*</span>}
                    </span>
                    <input
                      type={field.type}
                      required={field.req}
                      value={form[field.key]}
                      onChange={onChange(field.key)}
                      data-testid={`member-input-${field.key}`}
                      placeholder={field.hint || ""}
                      className="px-4 py-2.5 rounded-lg border border-kuswa-bg bg-white focus:border-kuswa-dark-blue focus:ring-2 focus:ring-kuswa-light-blue/30 outline-none transition"
                    />
                    {field.hint && (
                      <span className="text-[10px] text-kuswa-muted">{field.hint}</span>
                    )}
                  </label>
                ))}
                <button
                  type="submit"
                  disabled={submitting}
                  className="btn-primary sm:col-span-2 mt-2 disabled:opacity-60"
                  data-testid="member-submit-btn"
                >
                  {submitting ? t.common.loading : f.submit}
                </button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-5">
            <h3 className={`text-xl font-bold mb-4 ${lang === "bn" ? "font-bn" : "font-display"}`}>
              {lang === "bn" ? "আমাদের সদস্যবৃন্দ" : "Our Members"}
            </h3>
            <div className="space-y-3 max-h-[640px] overflow-auto pr-1" data-testid="public-members-list">
              {members.length === 0 && <div className="card-soft text-kuswa-muted">{t.common.empty}</div>}
              {members.map((m) => (
                <div key={m.id} className="card-soft !p-4 flex items-center gap-3" data-testid={`pub-member-${m.id}`}>
                  <div className="w-12 h-12 rounded-full bg-gradient-section grid place-items-center text-white font-bold">
                    {m.name?.[0]?.toUpperCase() || "K"}
                  </div>
                  <div>
                    <div className="font-semibold text-kuswa-dark-blue">{m.name}</div>
                    <div className="text-xs text-kuswa-muted">{m.profession || m.address}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

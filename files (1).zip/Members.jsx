import React, { useEffect, useState, useRef } from "react";
import { useLang } from "../context/LanguageContext";
import { api, formatApiError } from "../lib/api";
import { toast } from "sonner";
import { UserPlus, MessageCircle, Upload, Camera } from "lucide-react";

const initialForm = {
  name: "", father_name: "", dob: "", address: "", profession: "",
  institution: "", education: "", email: "", mobile: "", whatsapp: "",
  blood_group: "", nid_or_birth_reg: "", photo_url: "",
};

// ---------- Photo Upload Widget ----------
function PhotoUpload({ photoUrl, onUploaded }) {
  const inputRef = useRef();
  const [uploading, setUploading] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("ছবির আকার সর্বোচ্চ 5MB হতে পারবে।");
      return;
    }

    setUploading(true);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const res = await api.post("/upload/image/public", {
          filename: file.name,
          data: ev.target.result,
        });
        onUploaded(res.data.url);
        toast.success("ছবি আপলোড সফল হয়েছে ✅");
      } catch (err) {
        toast.error("আপলোড ব্যর্থ: " + (err.response?.data?.detail || err.message));
      } finally {
        setUploading(false);
      }
      e.target.value = "";
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Photo preview circle */}
      <div
        className="relative w-28 h-28 rounded-full border-2 border-dashed border-kuswa-light-blue bg-kuswa-bg flex items-center justify-center cursor-pointer overflow-hidden group"
        onClick={() => inputRef.current.click()}
      >
        {photoUrl ? (
          <>
            <img src={photoUrl} alt="প্রোফাইল" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center">
              <Camera size={22} className="text-white" />
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center gap-1 text-center px-2">
            {uploading ? (
              <div className="animate-spin w-6 h-6 border-2 border-kuswa-dark-blue border-t-transparent rounded-full" />
            ) : (
              <>
                <Upload size={22} className="text-kuswa-light-blue" />
                <span className="text-[10px] text-kuswa-muted leading-tight">ছবি আপলোড করুন</span>
              </>
            )}
          </div>
        )}
      </div>

      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />

      <div className="text-center">
        <button
          type="button"
          disabled={uploading}
          onClick={() => inputRef.current.click()}
          className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold border border-kuswa-dark-blue/30 text-kuswa-dark-blue hover:bg-kuswa-dark-blue hover:text-white transition disabled:opacity-50"
        >
          <Camera size={13} />
          {uploading ? "আপলোড হচ্ছে..." : photoUrl ? "ছবি পরিবর্তন করুন" : "ছবি বেছে নিন"}
        </button>
        <p className="text-[10px] text-kuswa-muted mt-1">JPG / PNG · সর্বোচ্চ 5MB</p>
      </div>
    </div>
  );
}

// ====================== Members Page ======================
export default function Members() {
  const { t, lang } = useLang();
  const [members,    setMembers]    = useState([]);
  const [form,       setForm]       = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.get("/members/public").then((r) => setMembers(r.data)).catch(() => {});
  }, []);

  const onChange = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();

    // Frontend validation for NID (mandatory)
    if (!form.nid_or_birth_reg || !form.nid_or_birth_reg.trim()) {
      toast.error(lang === "bn" ? "NID / জন্ম নিবন্ধন নম্বর আবশ্যক।" : "NID or Birth Registration number is required.");
      return;
    }

    setSubmitting(true);
    try {
      const payload = { ...form, whatsapp: form.whatsapp || form.mobile };
      await api.post("/members", payload);
      toast.success(t.member_form.success);
      setForm(initialForm);
    } catch (err) {
      toast.error(formatApiError(err.response?.data?.detail) || err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const f = t.member_form;

  // Fields definition — nid_or_birth_reg is now required: true
  const fields = [
    [{ key: "name",            label: f.name,          type: "text",  req: true }],
    [{ key: "father_name",     label: f.father_name,   type: "text",  req: true }],
    [{ key: "dob",             label: f.dob,            type: "date",  req: false }],
    [{ key: "address",         label: f.address,        type: "text",  req: true }],
    [{ key: "profession",      label: f.profession,     type: "text",  req: false }],
    [{ key: "institution",     label: f.institution,    type: "text",  req: false }],
    [{ key: "education",       label: f.education,      type: "text",  req: false }],
    [{ key: "email",           label: f.email,          type: "email", req: true }],
    [{ key: "mobile",          label: f.mobile,         type: "tel",   req: true }],
    [{
      key: "whatsapp",
      label: lang === "bn" ? "হোয়াটসঅ্যাপ নম্বর" : "WhatsApp Number",
      type: "tel",
      req: false,
      hint: lang === "bn" ? "ফাঁকা রাখলে মোবাইল নম্বর ব্যবহার হবে" : "Leave blank to use mobile number",
      icon: "wa",
    }],
    [{ key: "blood_group",     label: f.blood_group,   type: "text",  req: false }],
    [{
      key: "nid_or_birth_reg",
      label: f.nid,
      type: "text",
      req: true,  // ← NOW MANDATORY
      hint: lang === "bn" ? "জাতীয় পরিচয়পত্র বা জন্ম নিবন্ধন নম্বর দিন" : "Enter NID or Birth Registration number",
    }],
  ];

  return (
    <div data-testid="members-page">
      <section className="bg-gradient-soft py-20">
        <div className="container-x">
          <h1 className={`text-4xl sm:text-5xl font-bold ${lang === "bn" ? "font-bn" : "font-display"} text-kuswa-dark-blue`}>
            {t.sections.members_title}
          </h1>
          <p className="mt-3 text-kuswa-muted">{t.sections.members_sub}</p>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-x grid lg:grid-cols-12 gap-10">
          {/* Form */}
          <div className="lg:col-span-7">
            <div className="card-soft" data-testid="member-form-card">
              <h2 className={`text-2xl font-bold flex items-center gap-2 ${lang === "bn" ? "font-bn" : "font-display"}`}>
                <UserPlus className="text-kuswa-orange" /> {f.title}
              </h2>

              {/* WhatsApp notice */}
              <div className="mt-4 flex items-start gap-3 p-3 rounded-xl bg-green-50 border border-green-200">
                <MessageCircle size={18} className="text-green-600 mt-0.5 shrink-0" />
                <p className="text-xs text-green-700">
                  {lang === "bn"
                    ? "সদস্য অনুমোদনের পর কুশার সকল নোটিশ ও ইভেন্ট আপনার হোয়াটসঅ্যাপে পৌঁছে যাবে।"
                    : "After approval, all KUSWA notices and events will be sent to your WhatsApp."}
                </p>
              </div>

              <form onSubmit={submit} className="mt-6 space-y-4" data-testid="member-form">

                {/* Photo upload at top */}
                <div className="flex flex-col items-center py-4 border border-dashed border-kuswa-bg rounded-xl">
                  <p className="text-sm text-kuswa-muted font-medium mb-3">
                    {lang === "bn" ? "প্রোফাইল ছবি (ঐচ্ছিক)" : "Profile Photo (optional)"}
                  </p>
                  <PhotoUpload
                    photoUrl={form.photo_url}
                    onUploaded={(url) => setForm((f) => ({ ...f, photo_url: url }))}
                  />
                </div>

                {/* All form fields in 2-column grid */}
                <div className="grid sm:grid-cols-2 gap-4">
                  {fields.map(([field]) => (
                    <label key={field.key} className="flex flex-col gap-1.5 text-sm">
                      <span className="text-kuswa-muted font-medium flex items-center gap-1.5">
                        {field.icon === "wa" && <MessageCircle size={13} className="text-green-600" />}
                        {field.label}
                        {field.req && <span className="text-red-500 font-bold">*</span>}
                      </span>
                      <input
                        type={field.type}
                        required={field.req}
                        value={form[field.key]}
                        onChange={onChange(field.key)}
                        data-testid={`member-input-${field.key}`}
                        placeholder={field.hint || ""}
                        className={`px-4 py-2.5 rounded-lg border bg-white focus:ring-2 outline-none transition ${
                          field.req
                            ? "border-kuswa-dark-blue/30 focus:border-kuswa-dark-blue focus:ring-kuswa-light-blue/30"
                            : "border-kuswa-bg focus:border-kuswa-dark-blue focus:ring-kuswa-light-blue/20"
                        }`}
                      />
                      {field.hint && (
                        <span className="text-[10px] text-kuswa-muted">{field.hint}</span>
                      )}
                    </label>
                  ))}
                </div>

                {/* NID note */}
                <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-amber-600 text-sm mt-0.5">ℹ️</span>
                  <p className="text-xs text-amber-700">
                    {lang === "bn"
                      ? "NID / জন্ম নিবন্ধন নম্বর আবশ্যক — এটি সদস্যপদ যাচাইয়ের জন্য ব্যবহার করা হয়।"
                      : "NID / Birth Registration is required — it is used to verify membership."}
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="btn-primary w-full disabled:opacity-60"
                  data-testid="member-submit-btn"
                >
                  {submitting ? t.common.loading : f.submit}
                </button>
              </form>
            </div>
          </div>

          {/* Public members list */}
          <div className="lg:col-span-5">
            <h3 className={`text-xl font-bold mb-4 ${lang === "bn" ? "font-bn" : "font-display"}`}>
              {lang === "bn" ? "আমাদের সদস্যবৃন্দ" : "Our Members"}
            </h3>
            <div className="space-y-3 max-h-[640px] overflow-auto pr-1" data-testid="public-members-list">
              {members.length === 0 && <div className="card-soft text-kuswa-muted">{t.common.empty}</div>}
              {members.map((m) => (
                <div key={m.id} className="card-soft !p-4 flex items-center gap-3" data-testid={`pub-member-${m.id}`}>
                  {m.photo_url ? (
                    <img
                      src={m.photo_url}
                      alt={m.name}
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-kuswa-light-blue/30 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-gradient-section grid place-items-center text-white font-bold shrink-0">
                      {m.name?.[0]?.toUpperCase() || "K"}
                    </div>
                  )}
                  <div>
                    <div className="font-semibold text-kuswa-dark-blue">{m.name}</div>
                    <div className="text-xs text-kuswa-muted">{m.profession || m.address}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

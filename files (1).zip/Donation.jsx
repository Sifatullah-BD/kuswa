import React, { useEffect, useState } from "react";
import { useLang } from "../context/LanguageContext";
import { api } from "../lib/api";
import { Building2, Smartphone, Wallet, Copy, Check, Phone, ArrowRight, X } from "lucide-react";

function CopyRow({ label, value, testid }) {
  const [copied, setCopied] = useState(false);
  if (!value) return null;
  return (
    <div className="flex items-center justify-between gap-3 py-3 border-b border-kuswa-bg last:border-0" data-testid={testid}>
      <div>
        <div className="text-xs uppercase tracking-wider text-kuswa-muted font-semibold">{label}</div>
        <div className="font-mono font-semibold text-kuswa-dark-blue mt-0.5">{value}</div>
      </div>
      <button
        onClick={() => { navigator.clipboard.writeText(value); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold bg-kuswa-bg hover:bg-kuswa-dark-blue hover:text-white transition-colors"
      >
        {copied ? <><Check size={14} /> Copied</> : <><Copy size={14} /> Copy</>}
      </button>
    </div>
  );
}

function PaymentModal({ method, number, onClose, lang }) {
  const isBkash = method === "bkash";
  const isNagad = method === "nagad";
  const methodName = isBkash ? "বিকাশ" : isNagad ? "নগদ" : "রকেট";
  const methodNameEn = isBkash ? "bKash" : isNagad ? "Nagad" : "Rocket";
  const color = isBkash ? "#E2136E" : isNagad ? "#F26522" : "#8C3494";
  const [copied, setCopied] = useState(false);

  const steps = lang === "bn" ? [
    `আপনার ${methodName} অ্যাপ খুলুন`,
    `"Send Money" বা "পাঠান" সিলেক্ট করুন`,
    `নম্বরে পাঠান: ${number}`,
    `আপনার কাঙ্ক্ষিত পরিমাণ লিখুন`,
    `Reference-এ "KUSWA Donation" লিখুন`,
    `"Confirm" বা "নিশ্চিত করুন" চাপুন`,
  ] : [
    `Open your ${methodNameEn} app`,
    `Select "Send Money"`,
    `Send to number: ${number}`,
    `Enter your desired amount`,
    `Write "KUSWA Donation" in Reference`,
    `Tap "Confirm" to complete`,
  ];

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-6" style={{ background: color }}>
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">
              {lang === "bn" ? `${methodName}-এ অনুদান দিন` : `Donate via ${methodNameEn}`}
            </h3>
            <button onClick={onClose} className="text-white/80 hover:text-white"><X size={22} /></button>
          </div>
          <div className="mt-3 font-mono text-2xl font-bold text-white">{number}</div>
        </div>
        <div className="p-6">
          <p className="text-sm font-semibold text-kuswa-dark-blue mb-4">
            {lang === "bn" ? "নিচের ধাপগুলো অনুসরণ করুন:" : "Follow these steps:"}
          </p>
          <ol className="space-y-3">
            {steps.map((step, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-kuswa-ink">
                <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 text-white"
                  style={{ background: color }}>{i + 1}</span>
                {step}
              </li>
            ))}
          </ol>
          <div className="mt-5 p-3 rounded-xl bg-blue-50">
            <p className="text-xs font-semibold text-blue-700 flex items-center gap-2">
              <Phone size={14} />
              {lang === "bn"
                ? "অনুদানের পর আমাদের জানান: +880 1622-564511"
                : "After donating, notify us: +880 1622-564511"}
            </p>
          </div>
          <button
            onClick={() => { navigator.clipboard.writeText(number); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
            className="mt-4 w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold text-white transition hover:opacity-90"
            style={{ background: color }}
          >
            {copied ? <><Check size={16} />{lang === "bn" ? "কপি হয়েছে!" : "Copied!"}</> : <><Copy size={16} />{lang === "bn" ? "নম্বর কপি করুন" : "Copy Number"}</>}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Donation() {
  const { t, lang } = useLang();
  const [s, setS] = useState({});
  const [modal, setModal] = useState(null);

  useEffect(() => { api.get("/settings").then((r) => setS(r.data || {})).catch(() => {}); }, []);

  const d = t.donate;

  return (
    <div data-testid="donation-page">
      {modal && <PaymentModal method={modal.method} number={modal.number} onClose={() => setModal(null)} lang={lang} />}

      <section className="bg-gradient-soft py-20">
        <div className="container-x">
          <h1 className={`text-4xl sm:text-5xl font-bold ${lang === "bn" ? "font-bn" : "font-display"} text-kuswa-dark-blue`}>
            {lang === "bn" ? "অনুদান দিন" : "Donate to KUSWA"}
          </h1>
          <p className="mt-3 text-kuswa-muted max-w-2xl">{t.sections.donate_sub}</p>
        </div>
      </section>

      <section className="section-pad">
        <div className="container-x grid lg:grid-cols-3 gap-6">
          {/* Bank */}
          <div className="card-soft" data-testid="donate-bank-card">
            <div className="w-12 h-12 grid place-items-center rounded-xl bg-gradient-section text-white mb-4">
              <Building2 size={22} />
            </div>
            <h3 className="text-xl font-bold text-kuswa-dark-blue">{d.bank}</h3>
            <div className="mt-4">
              <CopyRow label={d.bank} value={s.bank_name} testid="donate-bank-name" />
              <CopyRow label={lang === "bn" ? "অ্যাকাউন্ট নাম" : "Account Holder"} value={s.bank_account_holder} testid="donate-bank-holder" />
              <CopyRow label={d.account} value={s.bank_account} testid="donate-bank-account" />
              <CopyRow label={d.branch} value={s.bank_branch} testid="donate-bank-branch" />
            </div>
            {s.bank_account && (
              <div className="mt-4 p-3 rounded-xl bg-blue-50 text-xs text-blue-700">
                {lang === "bn" ? "NPSB/BEFTN বা সরাসরি শাখায় যান।" : "Use NPSB/BEFTN or visit the branch directly."}
              </div>
            )}
          </div>

          {/* bKash */}
          <div className="card-soft" data-testid="donate-bkash-card">
            <div className="w-12 h-12 grid place-items-center rounded-xl mb-4" style={{ background: "#E2136E" }}>
              <Smartphone size={22} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-kuswa-dark-blue">{d.bkash}</h3>
            <div className="mt-4">
              <CopyRow label={d.bkash} value={s.bkash_number} testid="donate-bkash-number" />
              <div className="text-xs text-kuswa-muted mt-2">
                {lang === "bn" ? "Send Money অপশন ব্যবহার করুন" : "Use Send Money option"}
              </div>
            </div>
            {s.bkash_number ? (
              <button
                onClick={() => setModal({ method: "bkash", number: s.bkash_number })}
                className="mt-5 w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold text-white transition hover:opacity-90 active:scale-95"
                style={{ background: "#E2136E" }}
                data-testid="bkash-pay-btn"
              >
                <Smartphone size={16} />
                {lang === "bn" ? "বিকাশে পাঠান" : "Pay via bKash"}
                <ArrowRight size={15} />
              </button>
            ) : (
              <div className="mt-4 p-3 rounded-xl bg-gray-50 text-xs text-gray-400 text-center">
                {lang === "bn" ? "নম্বর কনফিগার হয়নি" : "Number not configured"}
              </div>
            )}
          </div>

          {/* Nagad + Rocket */}
          <div className="card-soft" data-testid="donate-nagad-card">
            <div className="w-12 h-12 grid place-items-center rounded-xl mb-4" style={{ background: "#F26522" }}>
              <Wallet size={22} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-kuswa-dark-blue">{d.nagad} / {d.rocket}</h3>
            <div className="mt-4">
              <CopyRow label={d.nagad} value={s.nagad_number} testid="donate-nagad-number" />
              <CopyRow label={d.rocket} value={s.rocket_number} testid="donate-rocket-number" />
            </div>
            <div className="mt-4 flex flex-col gap-2">
              {s.nagad_number ? (
                <button
                  onClick={() => setModal({ method: "nagad", number: s.nagad_number })}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold text-white transition hover:opacity-90 active:scale-95"
                  style={{ background: "#F26522" }}
                  data-testid="nagad-pay-btn"
                >
                  <Wallet size={16} />
                  {lang === "bn" ? "নগদে পাঠান" : "Pay via Nagad"}
                  <ArrowRight size={15} />
                </button>
              ) : null}
              {s.rocket_number ? (
                <button
                  onClick={() => setModal({ method: "rocket", number: s.rocket_number })}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold text-white transition hover:opacity-90 active:scale-95"
                  style={{ background: "#8C3494" }}
                  data-testid="rocket-pay-btn"
                >
                  <Smartphone size={16} />
                  {lang === "bn" ? "রকেটে পাঠান" : "Pay via Rocket"}
                  <ArrowRight size={15} />
                </button>
              ) : null}
              {!s.nagad_number && !s.rocket_number && (
                <div className="p-3 rounded-xl bg-gray-50 text-xs text-gray-400 text-center">
                  {lang === "bn" ? "নম্বর কনফিগার হয়নি" : "Numbers not configured"}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="container-x mt-10">
          <div className="rounded-2xl p-8 bg-gradient-section text-white">
            <h3 className={`text-2xl font-bold ${lang === "bn" ? "font-bn" : "font-display"}`}>
              {lang === "bn" ? "ধন্যবাদ আপনার সহমর্মিতার জন্য" : "Thank you for your generosity"}
            </h3>
            <p className="mt-2 text-white/90 max-w-2xl">
              {lang === "bn"
                ? "আপনার প্রতিটি অনুদান আমাদের সমাজ কল্যাণমূলক কাজকে আরও বিস্তৃত করছে। অনুদানের পর আমাদের জানাতে পারেন +880 1622-564511 নম্বরে।"
                : "Every contribution helps us expand our welfare work. After donating, please notify us at +880 1622-564511."}
            </p>
            <a
              href="tel:+8801622564511"
              className="mt-5 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white text-kuswa-dark-blue font-semibold text-sm hover:bg-white/90 transition"
            >
              <Phone size={16} /> +880 1622-564511
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
